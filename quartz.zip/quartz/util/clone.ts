import rfdc from "rfdc"

export const clone = rfdc()
